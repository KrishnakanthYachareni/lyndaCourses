package com.example.javase8.interfaces;

@FunctionalInterface
public interface SimpleInterface {
	public void doSomething();
}
