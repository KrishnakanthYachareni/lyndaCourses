package com.example.javase8.interfaces;

@FunctionalInterface
public interface InterfaceWithArgs {
	public void calculate(int value1, int value2);
}
