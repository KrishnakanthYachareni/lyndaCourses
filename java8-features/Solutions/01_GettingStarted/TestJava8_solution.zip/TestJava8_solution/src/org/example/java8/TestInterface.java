package org.example.java8;

@FunctionalInterface
public interface TestInterface {

	public void test();
	
}
